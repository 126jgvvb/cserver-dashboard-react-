import React from "react"
import { Password_Layout } from "../homepage/components/newPasswordLayout";
import { Helmet } from "react-helmet";
import './styles/passwordStyles.css'
 
function Password(){
    return(
        <div className="App">
            <Password_Layout/>
        </div>
    )
}

export default Password;