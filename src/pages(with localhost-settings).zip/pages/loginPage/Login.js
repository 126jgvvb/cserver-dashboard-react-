import React from "react"
import { Layout } from "../homepage/components/Loginlayout"
import './styles/loginStyles.css'

function Login(){
    return(
        <div className="App">
            <Layout/>
        </div>
    )
}

export default Login;