import React from "react";
import { Password_Credentials } from "./passwordCredentials.";

export const Password_Layout=()=>{
    return(
        <div className="loginLayout">
            <div className="loginCard">
                    <Password_Credentials/>
            </div>
        </div>
    )
}